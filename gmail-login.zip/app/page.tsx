import LoginScreen from "@/components/login-screen"

export default function Home() {
  return <LoginScreen />
}
